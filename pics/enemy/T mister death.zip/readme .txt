Bitte beachten:

Der Sprite besteht aus zwei Untersprites. Deswegen befinden sich auch zwei Ordner in dem Zipfile :

Da f�r den mister death working auf einem 96 X 96 er Tile schlichtweg zu wenig Platz vorhanden war,habe ich selbigen in einer Gr�sse von 128 X 128 gerendert.
Dies bedeutet, dass sich der Nullpunkt im Vergleich zum normalen mister death Sprite bei -16 / -16 befindet ...
Wenn ihr zwischen den sprites wechselt,solltet ihr darauf achten, ihn an der richtigen position relativ zum anderen zu erstellen:  -16/-16 oder 16/16 ...

Reiner

Attention :

The Sprite contains two subsprites. That�s why there are two folders in the Zipfile:

Because there wasn�t enough space to display the mister death working sprite at an 96 X 96 Tile, i have rendered it in a size of 128 x 128.
This means that the zero point of mister death working sprite is at -16 /-16 compared to the normal mister death sprite ...
when you are switching between the two sprites , take care to create it at the right position compared to the other: 16/16 or -16/-16 ...

Reiner


http://www.reinerstileset.de
email: reiner.prokein@t-online.de